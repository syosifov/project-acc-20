package net.yosifov.filipov.training.accounting.acc20;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Acc20Application {

	public static void main(String[] args) {
		SpringApplication.run(Acc20Application.class, args);
	}

}
